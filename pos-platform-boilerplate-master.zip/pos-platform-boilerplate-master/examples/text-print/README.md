# Example of printing text


In this example we will add button to order view, which will print current order check.   

Also we will list all available printers in device manager and will add a button for test printing. 
