# Пример Hello World

Этот пример добавляет кнопку на окно заказа и настроек, и по клику на кнопку показывает Popup. 
Также после закрытия заказа отображает Popup. 

Используются такие методы платформы: 

1. Добавить кнопки в интерфейс Poster — [Poster.interface.showApplicationIconAt](https://dev.joinposter.com/docs/v3/pos/interfaces/interface-showApplicationIconAt) 

2. Обработка ивентов — [Poster.on](https://dev.joinposter.com/docs/v3/pos/events/index)

3. Отобразить попап — [Poster.interface.popup](https://dev.joinposter.com/docs/v3/pos/interfaces/interface-popup)
